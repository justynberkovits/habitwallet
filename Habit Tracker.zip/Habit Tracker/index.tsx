"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useRouter } from 'next/navigation'

type Habit = {
  id: string
  name: string
  icon: string
}

const habits: Habit[] = [
  { id: "1", name: "Work Out", icon: "🏃" },
  { id: "2", name: "Eat Food", icon: "🍔" },
  { id: "3", name: "Music", icon: "🎤" },
  { id: "4", name: "Art & Design", icon: "🎨" },
  { id: "5", name: "Traveling", icon: "🗺️" },
  { id: "6", name: "Read Book", icon: "📚" },
  { id: "7", name: "Gaming", icon: "🎮" },
  { id: "8", name: "Mechanic", icon: "🔧" },
]

export default function ChooseHabit() {
  const [selectedHabits, setSelectedHabits] = useState<string[]>([])
  const router = useRouter()

  const toggleHabit = (habitId: string) => {
    setSelectedHabits(prev => 
      prev.includes(habitId)
        ? prev.filter(id => id !== habitId)
        : [...prev, habitId]
    )
  }

  const handleGetStarted = () => {
    if (selectedHabits.length > 0) {
      // Here you would typically save the selected habits to your state management solution or backend
      console.log("Selected habits:", selectedHabits)
      // Navigate to the schedule page
      router.push('/schedule')
    } else {
      alert("Please select at least one habit to get started.")
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardContent className="p-6">
          <h1 className="text-2xl font-bold mb-2">Choose habit</h1>
          <p className="text-gray-500 mb-6">Choose your daily habits, you can choose more than one</p>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            {habits.map((habit) => (
              <div
                key={habit.id}
                className={cn(
                  "p-4 rounded-xl text-center cursor-pointer transition-all",
                  selectedHabits.includes(habit.id) ? "border-2 border-red-200 bg-red-50" : "border border-gray-200"
                )}
                onClick={() => toggleHabit(habit.id)}
              >
                <div className="text-3xl mb-2">{habit.icon}</div>
                <div className="text-sm">{habit.name}</div>
              </div>
            ))}
          </div>

          <Button
            onClick={handleGetStarted}
            className="w-full bg-black text-white rounded-xl py-6 font-medium hover:bg-gray-800 transition-colors"
          >
            Get Started!
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}