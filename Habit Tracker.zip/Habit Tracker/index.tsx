"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  BarChart,
  Bell,
  Calendar,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Filter,
  LayoutDashboard,
  List,
  Menu,
  Moon,
  Plus,
  Search,
  Settings,
  Star,
  Sun,
  Timer,
} from "lucide-react"
import { cn } from "@/lib/utils"
import CalendarView from './calendar-view'
import { useTheme } from "next-themes"

type Habit = {
  id: string
  name: string
  emoji: string
  value: number
  type: "reward" | "penalty"
  dueDate: string
  frequency: "daily" | "weekly" | "monthly"
  days: string[]
  status: "Not Started" | "In Progress" | "Completed"
}

export default function Dashboard() {
  const [activeNav, setActiveNav] = useState("dashboard")
  const [habits, setHabits] = useState<Habit[]>([
    { id: "1", name: "30min Exercise", emoji: "🏋️", value: 5, type: "reward", dueDate: "2023-06-15", frequency: "daily", days: ["Monday", "Wednesday", "Friday"], status: "In Progress" },
    { id: "2", name: "No Social Media", emoji: "📵", value: 3, type: "penalty", dueDate: "2023-06-15", frequency: "daily", days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], status: "Completed" },
    { id: "3", name: "Meditation", emoji: "🧘", value: 2, type: "reward", dueDate: "2023-06-16", frequency: "daily", days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], status: "Not Started" },
  ])
  const [newHabit, setNewHabit] = useState<Partial<Habit>>({
    name: "",
    emoji: "😀",
    value: 0,
    type: "reward",
    dueDate: "",
    frequency: "daily",
    days: [],
  })
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const { theme, setTheme } = useTheme()

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light")
  }

  const addHabit = () => {
    if (newHabit.name && newHabit.value && newHabit.type && newHabit.dueDate && newHabit.frequency && newHabit.days && newHabit.days.length > 0) {
      setHabits([...habits, {
        id: Date.now().toString(),
        name: newHabit.name,
        emoji: newHabit.emoji || "😀",
        value: newHabit.value,
        type: newHabit.type,
        dueDate: newHabit.dueDate,
        frequency: newHabit.frequency,
        days: newHabit.days,
        status: "Not Started"
      } as Habit])
      setNewHabit({ name: "", emoji: "😀", value: 0, type: "reward", dueDate: "", frequency: "daily", days: [] })
      setIsCreateModalOpen(false)
    }
  }

  const totalSavings = habits.reduce((sum, habit) => 
    habit.status === "Completed" ? sum + habit.value : sum, 0
  )

  const completionRate = habits.length > 0
    ? (habits.filter(h => h.status === "Completed").length / habits.length * 100).toFixed(0)
    : "0"

  const metrics = [
    {
      title: "Active Habits",
      value: habits.length.toString(),
      description: "Habits currently being tracked",
      color: "bg-blue-500",
    },
    {
      title: "Total Savings",
      value: `$${totalSavings.toFixed(2)}`,
      description: "Accumulated through habits",
      color: "bg-green-500",
    },
    {
      title: "Completion Rate",
      value: `${completionRate}%`,
      description: "Average habit completion",
      color: "bg-purple-500",
    },
  ]

  const recentHabits = habits.slice(-3).reverse()

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <div className={cn(
        "bg-card text-card-foreground border-r transition-all duration-300 ease-in-out",
        isSidebarCollapsed ? "w-16" : "w-64"
      )}>
        <div className="flex items-center justify-between p-4">
          <div className={cn("flex items-center gap-2", isSidebarCollapsed && "hidden")}>
            <div className="w-8 h-8 bg-primary rounded-lg" />
            <span className="font-semibold text-lg">HabitWallet</span>
          </div>
          <Button variant="ghost" size="icon" onClick={toggleSidebar}>
            {isSidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        <nav className="space-y-1 p-2">
          {[
            { icon: LayoutDashboard, label: "Dashboard" },
            { icon: List, label: "My Habits" },
            { icon: Calendar, label: "Calendar" },
            { icon: Timer, label: "History" },
            { icon: Star, label: "Goals" },
            { icon: Bell, label: "Reminders" },
          ].map(({ icon: Icon, label }) => (
            <Button
              key={label}
              variant={activeNav === label.toLowerCase() ? "secondary" : "ghost"}
              className={cn(
                "w-full justify-start",
                isSidebarCollapsed && "justify-center"
              )}
              onClick={() => setActiveNav(label.toLowerCase())}
            >
              <Icon className="h-4 w-4 mr-2" />
              {!isSidebarCollapsed && <span>{label}</span>}
            </Button>
          ))}
        </nav>

        <div className="mt-8 p-2">
          <div className={cn("text-sm font-medium text-muted-foreground mb-2", isSidebarCollapsed && "hidden")}>WORKSPACE</div>
          <div className="space-y-1">
            <Button variant="secondary" className={cn("w-full justify-start", isSidebarCollapsed && "justify-center")}>
              <div className="w-6 h-6 bg-green-500 rounded text-white flex items-center justify-center text-sm mr-2">P</div>
              {!isSidebarCollapsed && <span>Personal</span>}
            </Button>
            <Button variant="ghost" className={cn("w-full justify-start", isSidebarCollapsed && "justify-center")}>
              <div className="w-6 h-6 bg-purple-500 rounded text-white flex items-center justify-center text-sm mr-2">F</div>
              {!isSidebarCollapsed && <span>Family</span>}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-card text-card-foreground border-b sticky top-0 z-10">
          <div className="flex items-center justify-between px-4 py-2">
            <div>
              <h1 className="text-xl font-semibold">Good morning, Alex!</h1>
              <p className="text-sm text-muted-foreground">Track your habits and grow your savings</p>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={toggleTheme}>
                {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </Button>
              <Button variant="outline">
                Customize
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
              <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create New
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Habit</DialogTitle>
                    <DialogDescription>Add a new habit to track. Set a monetary value as a reward or penalty.</DialogDescription>
                  </DialogHeader>
                  {/* ... (rest of the dialog content remains the same) ... */}
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          {activeNav === "dashboard" && (
            <>
              {/* Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {metrics.map((metric, i) => (
                  <Card key={i} className="p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-2xl font-bold">{metric.value}</div>
                        <div className="text-sm font-medium">{metric.title}</div>
                        <div className="text-sm text-muted-foreground">{metric.description}</div>
                      </div>
                      <div className={cn("w-3 h-3 rounded-full", metric.color)} />
                    </div>
                  </Card>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Recently Added */}
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-semibold">Recently Added</h2>
                      <p className="text-sm text-muted-foreground">New habits you've started tracking</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {recentHabits.map((habit) => (
                      <div key={habit.id} className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                        <div className="text-2xl">{habit.emoji}</div>
                        <div className="flex-1">
                          <div className="font-medium">{habit.name}</div>
                          <div className="text-sm text-muted-foreground">${habit.value} {habit.type}</div>
                        </div>
                        <div className="text-sm text-muted-foreground">{habit.dueDate}</div>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Completion Rate */}
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-lg font-semibold">Completion Rate</h2>
                      <p className="text-sm text-muted-foreground">Your habit success over time</p>
                    </div>
                  </div>
                  <div className="h-[200px] flex items-end gap-2">
                    {habits.map((habit) => (
                      <div
                        key={habit.id}
                        className={cn(
                          "flex-1 rounded-t",
                          habit.status === "Completed" ? "bg-green-500" : 
                          habit.status === "In Progress" ? "bg-yellow-500" : "bg-muted"
                        )}
                        style={{ height: `${habit.status === "Completed" ? 100 : habit.status === "In Progress" ? 50 : 20}%` }}
                      />
                    ))}
                  </div>
                </Card>
              </div>

              {/* Assigned Habits Table */}
              <Card className="mt-8">
                <div className="p-6 border-b">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-semibold">Current Habits</h2>
                      <p className="text-sm text-muted-foreground">Showing all habits assigned to you</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input className="pl-10" placeholder="Search habits..." />
                      </div>
                      <Button variant="outline" size="icon">
                        <Filter className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Habit</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Frequency</TableHead>
                      <TableHead>Days</TableHead>
                      <TableHead>Start Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {habits.map((habit) => (
                      <TableRow key={habit.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{habit.emoji}</span>
                <span>{habit.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>${habit.value.toFixed(2)}</TableCell>
                        <TableCell>
                          <span className={cn(
                            "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                            habit.type === "reward" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                          )}>
                            {habit.type}
                          </span>
                        </TableCell>
                        <TableCell>{habit.frequency}</TableCell>
                        <TableCell>{habit.days.map(day => day.slice(0, 3)).join(", ")}</TableCell>
                        <TableCell>{habit.dueDate}</TableCell>
                        <TableCell>
                          <span className={cn(
                            "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                            {
                              "bg-yellow-100 text-yellow-700": habit.status === "In Progress",
                              "bg-green-100 text-green-700": habit.status === "Completed",
                              "bg-gray-100 text-gray-700": habit.status === "Not Started"
                            }
                          )}>
                            {habit.status}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </>
          )}
          {activeNav === "calendar" && (
            <CalendarView habits={habits} />
          )}
        </main>
      </div>
    </div>
  )
}