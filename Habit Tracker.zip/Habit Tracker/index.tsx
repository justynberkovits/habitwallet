"use client"

import { useState, useEffect } from 'react'
import { useTheme } from 'next-themes'
import { Sun, Moon, DollarSign, Check, X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

type Habit = {
  id: number
  name: string
  value: number
  isReward: boolean
  completed: boolean
}

export default function Dashboard() {
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()
  const [habits, setHabits] = useState<Habit[]>([
    { id: 1, name: "Morning Workout", value: 5, isReward: true, completed: false },
    { id: 2, name: "Read for 30 minutes", value: 3, isReward: true, completed: false },
    { id: 3, name: "No junk food", value: 10, isReward: false, completed: true },
  ])

  useEffect(() => setMounted(true), [])

  const toggleHabit = (id: number) => {
    setHabits(habits.map(habit => 
      habit.id === id ? { ...habit, completed: !habit.completed } : habit
    ))
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Habit Tracker</h1>
          <Switch
            checked={theme === 'dark'}
            onCheckedChange={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="ml-4"
          >
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Switch>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {habits.map(habit => (
            <Card key={habit.id} className={`${habit.completed ? 'bg-green-50 dark:bg-green-900' : ''}`}>
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  {habit.name}
                  <Button
                    variant={habit.completed ? "outline" : "default"}
                    size="sm"
                    onClick={() => toggleHabit(habit.id)}
                  >
                    {habit.completed ? <X className="h-4 w-4" /> : <Check className="h-4 w-4" />}
                  </Button>
                </CardTitle>
                <CardDescription>
                  {habit.isReward ? 'Reward' : 'Penalty'}: ${habit.value.toFixed(2)}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  {habit.isReward
                    ? `Earn $${habit.value.toFixed(2)} for completing this habit`
                    : `Avoid a $${habit.value.toFixed(2)} penalty by completing this habit`}
                </p>
              </CardContent>
              <CardFooter>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Status: {habit.completed ? 'Completed' : 'Pending'}
                </p>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}