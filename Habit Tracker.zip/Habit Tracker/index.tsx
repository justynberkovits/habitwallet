"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  BarChart,
  Bell,
  ChevronDown,
  Filter,
  LayoutDashboard,
  List,
  Plus,
  Search,
  Settings,
  Star,
  Timer,
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function Component() {
  const [activeNav, setActiveNav] = useState("dashboard")

  const metrics = [
    {
      title: "Active Habits",
      value: "72",
      description: "Habits currently being tracked",
      color: "bg-blue-500",
    },
    {
      title: "Total Savings",
      value: "$2.1k",
      description: "Accumulated through habits",
      color: "bg-green-500",
    },
    {
      title: "Completion Rate",
      value: "51%",
      description: "Average habit completion",
      color: "bg-purple-500",
    },
  ]

  const recentHabits = [
    { name: "Morning Meditation", project: "Wellness Goals", date: "Today" },
    { name: "No Sugar Challenge", project: "Health Goals", date: "Yesterday" },
    { name: "Reading Session", project: "Personal Growth", date: "2 days ago" },
  ]

  const assignedHabits = [
    {
      name: "30min Exercise",
      value: "$5",
      type: "reward",
      dueDate: "Today",
      status: "In Progress",
    },
    {
      name: "No Social Media",
      value: "$3",
      type: "penalty",
      dueDate: "Today",
      status: "Completed",
    },
    {
      name: "Meditation",
      value: "$2",
      type: "reward",
      dueDate: "Tomorrow",
      status: "Not Started",
    },
  ]

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r p-4">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-blue-600 rounded-lg" />
          <span className="font-semibold text-lg">HabitWallet</span>
        </div>

        <nav className="space-y-1">
          {[
            { icon: LayoutDashboard, label: "Dashboard" },
            { icon: List, label: "My Habits" },
            { icon: Timer, label: "History" },
            { icon: Star, label: "Goals" },
            { icon: Bell, label: "Reminders" },
          ].map(({ icon: Icon, label }) => (
            <button
              key={label}
              onClick={() => setActiveNav(label.toLowerCase())}
              className={cn(
                "flex items-center gap-2 w-full px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100",
                activeNav === label.toLowerCase() && "bg-gray-100 text-blue-600 font-medium"
              )}
            >
              <Icon className="w-5 h-5" />
              {label}
            </button>
          ))}
        </nav>

        <div className="mt-8">
          <div className="text-sm font-medium text-gray-400 mb-2">WORKSPACE</div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-50 text-blue-600">
              <div className="w-6 h-6 bg-green-500 rounded text-white flex items-center justify-center text-sm">P</div>
              Personal
            </div>
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-gray-600">
              <div className="w-6 h-6 bg-purple-500 rounded text-white flex items-center justify-center text-sm">F</div>
              Family
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b sticky top-0 z-10">
          <div className="flex items-center justify-between px-8 py-4">
            <div>
              <h1 className="text-xl font-semibold">Good morning, Alex!</h1>
              <p className="text-sm text-gray-500">Track your habits and grow your savings</p>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline">
                Customize
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create New
              </Button>
            </div>
          </div>
        </header>

        <main className="p-8">
          {/* Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {metrics.map((metric, i) => (
              <Card key={i} className="p-6">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-2xl font-bold">{metric.value}</div>
                    <div className="text-sm font-medium">{metric.title}</div>
                    <div className="text-sm text-gray-500">{metric.description}</div>
                  </div>
                  <div className={cn("w-3 h-3 rounded-full", metric.color)} />
                </div>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Recently Added */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-semibold">Recently Added</h2>
                  <p className="text-sm text-gray-500">New habits you've started tracking</p>
                </div>
              </div>
              <div className="space-y-4">
                {recentHabits.map((habit, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium">{habit.name}</div>
                      <div className="text-sm text-gray-500">in /{habit.project}</div>
                    </div>
                    <div className="text-sm text-gray-500">{habit.date}</div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Completion Rate */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-semibold">Completion Rate</h2>
                  <p className="text-sm text-gray-500">Your habit success over time</p>
                </div>
              </div>
              <div className="h-[200px] flex items-end gap-2">
                {[40, 60, 30, 70, 50, 80, 45].map((height, i) => (
                  <div key={i} className="flex-1 bg-blue-100 rounded-t" style={{ height: `${height}%` }} />
                ))}
              </div>
            </Card>
          </div>

          {/* Assigned Habits Table */}
          <Card className="mt-8">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold">Current Habits</h2>
                  <p className="text-sm text-gray-500">Showing all habits assigned to you</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input className="pl-10" placeholder="Search habits..." />
                  </div>
                  <Button variant="outline" size="icon">
                    <Filter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Habit Name</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assignedHabits.map((habit, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">{habit.name}</TableCell>
                    <TableCell>{habit.value}</TableCell>
                    <TableCell>
                      <span className={cn(
                        "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                        habit.type === "reward" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                      )}>
                        {habit.type}
                      </span>
                    </TableCell>
                    <TableCell>{habit.dueDate}</TableCell>
                    <TableCell>
                      <span className={cn(
                        "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
                        {
                          "bg-yellow-100 text-yellow-700": habit.status === "In Progress",
                          "bg-green-100 text-green-700": habit.status === "Completed",
                          "bg-gray-100 text-gray-700": habit.status === "Not Started"
                        }
                      )}>
                        {habit.status}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </main>
      </div>
    </div>
  )
}