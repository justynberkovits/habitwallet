"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import {
  BarChart,
  Bell,
  Calendar,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Filter,
  LayoutDashboard,
  List,
  Menu,
  Moon,
  Plus,
  Search,
  Settings,
  Star,
  Sun,
  Timer,
} from "lucide-react"
import { cn } from "@/lib/utils"
import CalendarView from './calendar-view'
import { useTheme } from "next-themes"
import EmojiPicker from 'emoji-picker-react'

type Habit = {
  id: string
  name: string
  emoji: string
  value: number
  type: "reward" | "penalty"
  dueDate: string
  frequency: "daily" | "weekly" | "monthly"
  days: string[]
  status: "Not Started" | "In Progress" | "Completed"
}

export default function Dashboard() {
  const [activeNav, setActiveNav] = useState("dashboard")
  const [habits, setHabits] = useState<Habit[]>([
    { id: "1", name: "30min Exercise", emoji: "🏋️", value: 5, type: "reward", dueDate: "2023-06-15", frequency: "daily", days: ["Monday", "Wednesday", "Friday"], status: "In Progress" },
    { id: "2", name: "No Social Media", emoji: "📵", value: 3, type: "penalty", dueDate: "2023-06-15", frequency: "daily", days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], status: "Completed" },
    { id: "3", name: "Meditation", emoji: "🧘", value: 2, type: "reward", dueDate: "2023-06-16", frequency: "daily", days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], status: "Not Started" },
  ])
  const [newHabit, setNewHabit] = useState<Partial<Habit>>({
    name: "",
    emoji: "😀",
    value: 0,
    type: "reward",
    dueDate: "",
    frequency: "daily",
    days: [],
  })
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const { theme, setTheme } = useTheme()

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light")
  }

  const addHabit = () => {
    if (newHabit.name && newHabit.value && newHabit.type && newHabit.dueDate && newHabit.frequency && newHabit.days && newHabit.days.length > 0) {
      setHabits([...habits, {
        id: Date.now().toString(),
        name: newHabit.name,
        emoji: newHabit.emoji || "😀",
        value: newHabit.value,
        type: newHabit.type,
        dueDate: newHabit.dueDate,
        frequency: newHabit.frequency,
        days: newHabit.days,
        status: "Not Started"
      } as Habit])
      setNewHabit({ name: "", emoji: "😀", value: 0, type: "reward", dueDate: "", frequency: "daily", days: [] })
      setIsCreateModalOpen(false)
    }
  }

  const totalSavings = habits.reduce((sum, habit) => 
    habit.status === "Completed" ? sum + habit.value : sum, 0
  )

  const completionRate = habits.length > 0
    ? (habits.filter(h => h.status === "Completed").length / habits.length * 100).toFixed(0)
    : "0"

  const metrics = [
    {
      title: "Active Habits",
      value: habits.length.toString(),
      description: "Habits currently being tracked",
      color: "bg-blue-500",
    },
    {
      title: "Total Savings",
      value: `$${totalSavings.toFixed(2)}`,
      description: "Accumulated through habits",
      color: "bg-green-500",
    },
    {
      title: "Completion Rate",
      value: `${completionRate}%`,
      description: "Average habit completion",
      color: "bg-purple-500",
    },
  ]

  const recentHabits = habits.slice(-3).reverse()

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <div className={cn(
        "bg-card text-card-foreground border-r transition-all duration-300 ease-in-out",
        isSidebarCollapsed ? "w-16" : "w-64"
      )}>
        {/* ... (sidebar content remains unchanged) ... */}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-card text-card-foreground border-b sticky top-0 z-10">
          <div className="flex items-center justify-between px-4 py-2">
            <div>
              <h1 className="text-xl font-semibold">Good morning, Alex!</h1>
              <p className="text-sm text-muted-foreground">Track your habits and grow your savings</p>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={toggleTheme}>
                {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </Button>
              <Button variant="outline">
                Customize
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
              <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create New
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Habit</DialogTitle>
                    <DialogDescription>Add a new habit to track. Set a monetary value as a reward or penalty.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input
                        id="name"
                        value={newHabit.name}
                        onChange={(e) => setNewHabit({ ...newHabit, name: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="emoji" className="text-right">
                        Emoji
                      </Label>
                      <div className="col-span-3 flex items-center gap-2">
                        <Button
                          variant="outline"
                          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                        >
                          {newHabit.emoji}
                        </Button>
                        {showEmojiPicker && (
                          <div className="absolute mt-2 z-10">
                            <EmojiPicker
                              onEmojiClick={(emojiObject) => {
                                setNewHabit({ ...newHabit, emoji: emojiObject.emoji })
                                setShowEmojiPicker(false)
                              }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="value" className="text-right">
                        Value ($)
                      </Label>
                      <Input
                        id="value"
                        type="number"
                        value={newHabit.value}
                        onChange={(e) => setNewHabit({ ...newHabit, value: parseFloat(e.target.value) })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="type" className="text-right">
                        Type
                      </Label>
                      <Select
                        value={newHabit.type}
                        onValueChange={(value) => setNewHabit({ ...newHabit, type: value as "reward" | "penalty" })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select a type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="reward">Reward</SelectItem>
                          <SelectItem value="penalty">Penalty</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="frequency" className="text-right">
                        Frequency
                      </Label>
                      <Select
                        value={newHabit.frequency}
                        onValueChange={(value) => setNewHabit({ ...newHabit, frequency: value as "daily" | "weekly" | "monthly" })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="days" className="text-right">
                        Days
                      </Label>
                      <div className="col-span-3 flex flex-wrap gap-2">
                        {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                          <Button
                            key={day}
                            variant="outline"
                            size="sm"
                            className={cn(
                              newHabit.days?.includes(day) && "bg-primary text-primary-foreground"
                            )}
                            onClick={() => {
                              const updatedDays = newHabit.days?.includes(day)
                                ? newHabit.days.filter((d) => d !== day)
                                : [...(newHabit.days || []), day]
                              setNewHabit({ ...newHabit, days: updatedDays })
                            }}
                          >
                            {day.slice(0, 3)}
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="dueDate" className="text-right">
                        Start Date
                      </Label>
                      <Input
                        id="dueDate"
                        type="date"
                        value={newHabit.dueDate}
                        onChange={(e) => setNewHabit({ ...newHabit, dueDate: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  <Button onClick={addHabit}>Add Habit</Button>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-auto p-6">
          {/* ... (main content remains unchanged) ... */}
        </main>
      </div>
    </div>
  )
}