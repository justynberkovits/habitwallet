"use client"

import { useState } from "react"
import { Calendar, ChevronRight, LayoutGrid, LineChart, X } from "lucide-react"
import { cn } from "@/lib/utils"

type Habit = {
  id: string
  name: string
  icon: string
  selected?: boolean
}

type ScheduledHabit = {
  id: string
  name: string
  icon: string
  time: string
  duration: string
  completed: boolean
}

export default function Component() {
  const [activeTab, setActiveTab] = useState<"choose" | "schedule" | "stats">("choose")
  const [selectedDate, setSelectedDate] = useState(6)

  const habits: Habit[] = [
    { id: "1", name: "Work Out", icon: "🏃" },
    { id: "2", name: "Eat Food", icon: "🍔" },
    { id: "3", name: "Music", icon: "🎤" },
    { id: "4", name: "Art & Design", icon: "🎨" },
    { id: "5", name: "Traveling", icon: "🗺️" },
    { id: "6", name: "Read Book", icon: "📚", selected: true },
    { id: "7", name: "Gaming", icon: "🎮" },
    { id: "8", name: "Mechanic", icon: "🔧" },
  ]

  const scheduledHabits: ScheduledHabit[] = [
    { id: "1", name: "Bicycle", icon: "🚴", time: "07:00", duration: "for 10km", completed: true },
    { id: "2", name: "Running", icon: "🏃", time: "12:00", duration: "for 5km", completed: true },
    { id: "3", name: "Workout", icon: "🏋️", time: "15:00", duration: "for 1hr", completed: true },
    { id: "4", name: "Reading", icon: "📚", time: "20:00", duration: "for 30min", completed: false },
  ]

  const challenges = [
    { name: "Swimming in the sea", icon: "🏊", calories: 322, completed: true },
    { name: "Run 4 laps in court", icon: "🏃", calories: 420, completed: true },
    { name: "Yoga at 10.00pm", icon: "🧘", calories: 200, completed: false },
  ]

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-lg overflow-hidden">
        {activeTab === "choose" && (
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-2">Choose habit</h1>
            <p className="text-gray-500 mb-6">Choose your daily habits, you can choose more than one</p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              {habits.map((habit) => (
                <div
                  key={habit.id}
                  className={cn(
                    "p-4 rounded-xl text-center cursor-pointer transition-all",
                    habit.selected ? "border-2 border-red-200 bg-red-50" : "border border-gray-200"
                  )}
                >
                  <div className="text-3xl mb-2">{habit.icon}</div>
                  <div className="text-sm">{habit.name}</div>
                </div>
              ))}
            </div>

            <button
              onClick={() => setActiveTab("schedule")}
              className="w-full bg-black text-white rounded-xl py-4 font-medium"
            >
              Get Started!
            </button>
          </div>
        )}

        {activeTab === "schedule" && (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <LayoutGrid className="w-6 h-6" />
              <div className="text-gray-600">Wednesday, 24</div>
              <Calendar className="w-6 h-6" />
            </div>

            <div className="bg-gray-900 text-white p-4 rounded-xl mb-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="bg-green-500 p-2 rounded-lg">
                  📚
                </div>
                <div>
                  <div className="font-medium">Notification!</div>
                  <div className="text-sm text-gray-300">Now is the time to read the book, you can change it in settings.</div>
                </div>
                <X className="w-5 h-5 ml-auto" />
              </div>
            </div>

            <div className="flex gap-4 mb-6 overflow-x-auto py-2">
              {[6, 7, 8, 9, 10].map((date) => (
                <div
                  key={date}
                  onClick={() => setSelectedDate(date)}
                  className={cn(
                    "flex-shrink-0 w-16 h-16 rounded-xl flex flex-col items-center justify-center cursor-pointer",
                    selectedDate === date ? "bg-red-500 text-white" : "bg-gray-100"
                  )}
                >
                  <div className="text-sm">{["Tue", "Wed", "Thu", "Fri", "Sat"][date - 6]}</div>
                  <div className="font-medium">{String(date).padStart(2, '0')}</div>
                </div>
              ))}
            </div>

            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Tuesday habit</h2>
              <button className="text-gray-500 text-sm">See all</button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {scheduledHabits.map((habit) => (
                <div
                  key={habit.id}
                  className={cn(
                    "p-4 rounded-xl",
                    habit.completed ? "bg-green-50" : "bg-purple-50"
                  )}
                >
                  <div className="text-3xl mb-2">{habit.icon}</div>
                  <div className="font-medium">{habit.name}</div>
                  <div className="text-sm text-gray-500">{habit.time} {habit.duration}</div>
                  {habit.completed && <div className="text-green-500 text-sm">✓</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "stats" && (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <LayoutGrid className="w-6 h-6" />
              <div className="text-gray-600">Calorie stats</div>
              <Calendar className="w-6 h-6" />
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Analytics</h2>
              <div className="text-sm text-gray-500 mb-2">7,830 Calls</div>
              <div className="bg-red-50 rounded-xl p-4 mb-4">
                <div className="flex items-center gap-2 text-red-500">
                  <div>🔥</div>
                  <div>Burn</div>
                  <div className="ml-auto">535 Calls</div>
                </div>
              </div>
              <div className="h-40 bg-gray-50 rounded-xl p-4 flex items-end gap-2">
                {[60, 80, 40, 70, 90, 100, 30].map((height, i) => (
                  <div
                    key={i}
                    className={cn(
                      "w-full rounded-t",
                      i === 5 ? "bg-red-500" : "bg-gray-200"
                    )}
                    style={{ height: `${height}%` }}
                  />
                ))}
              </div>
            </div>

            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Challenge</h2>
              <button className="text-gray-500 text-sm">See all</button>
            </div>

            <div className="space-y-4">
              {challenges.map((challenge, i) => (
                <div key={i} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                  <div className="text-2xl">{challenge.icon}</div>
                  <div className="flex-1">
                    <div className="font-medium">{challenge.name}</div>
                    <div className={cn(
                      "text-sm",
                      challenge.completed ? "text-green-500" : "text-red-500"
                    )}>
                      {challenge.completed ? "Completed!" : "Not Started!"}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-sm">
                    🔥
                    <span>{challenge.calories}</span>
                    <span className="text-gray-500">calls</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-around items-center border-t p-4">
          <button
            onClick={() => setActiveTab("choose")}
            className={cn(
              "p-2 rounded-lg",
              activeTab === "choose" ? "bg-gray-100" : ""
            )}
          >
            <LayoutGrid className="w-6 h-6" />
          </button>
          <button
            onClick={() => setActiveTab("schedule")}
            className={cn(
              "p-2 rounded-lg",
              activeTab === "schedule" ? "bg-gray-100" : ""
            )}
          >
            <Calendar className="w-6 h-6" />
          </button>
          <button
            onClick={() => setActiveTab("stats")}
            className={cn(
              "p-2 rounded-lg",
              activeTab === "stats" ? "bg-gray-100" : ""
            )}
          >
            <LineChart className="w-6 h-6" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-200" />
        </div>
      </div>
    </div>
  )
}